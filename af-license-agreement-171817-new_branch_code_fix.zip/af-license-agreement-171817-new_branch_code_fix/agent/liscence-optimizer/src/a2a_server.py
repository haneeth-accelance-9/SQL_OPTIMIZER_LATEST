"""
License Optimizer — A2A Server Entrypoint.

Aligned with the agentic-AI platform standard (af-uc005 / af-uc003 reference MVPs):
  1. A2AFactory().create_server() — SDK-managed phased-orchestration executor (reads config.yaml).
  2. /health liveness probe registered for Azure Container Apps.
  3. Debugpy support for VS Code remote debugging.

Environment variables:
  PORT / HOST          — Server binding (default: 8001 / 0.0.0.0)
  DEBUGPY_ENABLE / DEBUGPY_WAIT / DEBUGPY_PORT
"""

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

from agenticai.a2a import A2AFactory

try:
    from . import tools  # noqa: F401
except ImportError:
    import tools  # noqa: F401


# ---------------------------------------------------------------------------
# Health route  (/health — liveness probe for Azure Container Apps)
# ---------------------------------------------------------------------------

def _register_health_route(fastapi_app: Any) -> None:
    """Register /health liveness probe. Listed in config.yaml public_paths."""
    try:
        from fastapi import APIRouter

        router = APIRouter()

        @router.get("/health", include_in_schema=False)
        def health() -> dict[str, str]:
            return {"status": "healthy"}

        fastapi_app.include_router(router)
    except Exception as exc:
        logger.warning("Could not register /health route: %s", exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------



def main() -> None:
    """Start the License Optimizer A2A server."""
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )

    if os.environ.get("DEBUGPY_ENABLE", "").lower() == "true":
        try:
            import debugpy

            port = int(os.environ.get("DEBUGPY_PORT", "5678"))
            debugpy.listen(("0.0.0.0", port))  # nosec B104 — intentional for VS Code remote debugging
            logger.info("debugpy listening on port %d", port)
            if os.environ.get("DEBUGPY_WAIT", "").lower() == "true":
                logger.info("Waiting for VS Code debugger to attach...")
                debugpy.wait_for_client()
                logger.info("Debugger attached")
        except ImportError:
            logger.warning("debugpy not installed — continuing without debugger")
        except Exception as exc:
            logger.warning("debugpy setup failed: %s", exc)

    factory = A2AFactory()
    server = factory.create_server()

    _register_health_route(server.fastapi_app)

    logger.info("License Optimizer agent server ready")
    server.run()


if __name__ == "__main__":
    main()
