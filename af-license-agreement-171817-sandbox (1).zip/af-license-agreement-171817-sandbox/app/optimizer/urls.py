from django.urls import path

from . import views

app_name = "optimizer"

urlpatterns = [
    # ── OAuth2 JWT token endpoints ─────────────────────────────────────────────
    # POST /api/auth/token/          → obtain access + refresh tokens
    # POST /api/auth/token/refresh/  → exchange refresh token for new access token
    # POST /api/auth/token/verify/   → inspect / validate an access token
    path("api/auth/token/", views.api_auth_token, name="api_auth_token"),
    path(
        "api/auth/token/refresh/",
        views.api_auth_token_refresh,
        name="api_auth_token_refresh",
    ),
    path(
        "api/auth/token/verify/",
        views.api_auth_token_verify,
        name="api_auth_token_verify",
    ),
    # ── Health / readiness ────────────────────────────────────────────────────
    path("health/", views.health, name="health"),
    path("ready/", views.ready, name="ready"),
    path("", views.home, name="home"),
    path("upload/", views.upload_view, name="upload"),
    path("login/", views.OptimizerLoginView.as_view(), name="login"),
    path("signup/", views.signup_view, name="signup"),
    path("logout/", views.logout_view, name="logout"),
    path("profile/", views.profile_page, name="profile"),
    path("results/", views.results, name="results"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("analysis-logs/", views.analysis_logs, name="analysis_logs"),
    path("alerts/", views.alerts, name="alerts"),
    path("report/", views.report_page, name="report"),
    path(
        "report/download/<str:format_type>/",
        views.report_download,
        name="report_download",
    ),
    path(
        "data/download/uc1-input/",
        views.download_uc1_input_data,
        name="download_uc1_input_data",
    ),
    path(
        "data/download/demand/", views.download_demand_data, name="download_demand_data"
    ),
    path(
        "data/download/<str:rule_id>/",
        views.download_rule_data,
        name="download_rule_data",
    ),
    path(
        "rightsizing/download/<str:sheet_key>/",
        views.download_rightsizing_sheet,
        name="download_rightsizing_sheet",
    ),
    path(
        "api/strategy3-rightsizing/",
        views.api_strategy3_rightsizing,
        name="api_strategy3_rightsizing",
    ),
    path("api/rule1-data/", views.api_rule1_data, name="api_rule1_data"),
    path("api/rule2-data/", views.api_rule2_data, name="api_rule2_data"),
    # ── Summary / BI API endpoints ────────────────────────────────────────────
    # GET  /api/dashboard-summary/           → complete KPI summary for all dashboard tabs
    path(
        "api/dashboard-summary/",
        views.api_dashboard_summary,
        name="api_dashboard_summary",
    ),
    # GET  /api/savings-summary/             → all three strategies + totals (PowerBI)
    path("api/savings-summary/", views.api_savings_summary, name="api_savings_summary"),
    # GET  /api/usu-data/                    → MySQL and/or Oracle (Java) installations + demand details
    #      ?family=mysql|oracle|all          filter by product family (default: all)
    #      ?type=all|installations|demand    filter by data type (default: all)
    #      ?page=1&page_size=100             pagination (max 500)
    #      ?hosting=Public+Cloud             filter by normalized hosting zone
    #      ?status=Installed|Retired         filter by install status (installations only)
    path("api/usu-data/", views.api_oracle_data, name="api_oracle_data"),
    # ── Agentic AI API endpoints ───────────────────────────────────────────────
    # GET  /api/agent-runs/                  → list recent agent runs
    # POST /api/agent-runs/trigger/          → trigger a new agent run
    # GET  /api/agent-runs/<run_id>/         → detail + candidates for one run
    # POST /api/candidates/<id>/decision/    → accept or reject a candidate
    path("api/agent-runs/", views.api_agent_runs, name="api_agent_runs"),
    path(
        "api/agent-runs/trigger/",
        views.api_trigger_agent_run,
        name="api_trigger_agent_run",
    ),
    path(
        "api/agent-runs/<uuid:run_id>/",
        views.api_agent_run_detail,
        name="api_agent_run_detail",
    ),
    path(
        "api/candidates/<uuid:candidate_id>/decision/",
        views.api_candidate_decision,
        name="api_candidate_decision",
    ),
    # GET  /api/boones-raw-data/            → paginated raw Boone's flat file rows from BoonesRawRow table
    #      ?page=1&page_size=100            pagination (max 500)
    #      ?server=SRV-001                  filter by server name (contains)
    #      ?sort_field=ingested_at          sort field: ingested_at | server_name
    #      ?sort_order=desc                 sort direction: asc | desc
    path("api/boones-raw-data/", views.api_boones_raw_data, name="api_boones_raw_data"),
    # GET  /api/dq-usu-data/               → paginated USU installations for Data Quality table
    #      ?family=mssql|oracle|all         filter by product family (default: all)
    #      ?page=1&page_size=100            pagination (max 500)
    #      ?sort_field=server_name          sortable fields (see view docstring)
    #      ?sort_order=asc|desc
    path("api/dq-usu-data/", views.api_dq_usu_data, name="api_dq_usu_data"),
    # GET  /api/dq-grafana-data/            → paginated Grafana metrics for Data Quality table
    #      Returns snapshot rows if available, rollup rows as fallback
    #      ?page=1&page_size=100&sort_field=timestamp&sort_order=desc
    path("api/dq-grafana-data/", views.api_dq_grafana_data, name="api_dq_grafana_data"),
    # ── Admin Panel: User Management ──────────────────────────────────────────
    path("admin/", views.admin_panel, name="admin_panel"),
    path("api/admin/users/", views.api_admin_users, name="api_admin_users"),
    path(
        "api/admin/users/<int:user_id>/",
        views.api_admin_user_detail,
        name="api_admin_user_detail",
    ),
]
