"""
URL configuration for SQL License Optimizer.
"""

from django.urls import include, path

urlpatterns = [
    path("", include("optimizer.urls")),
]
