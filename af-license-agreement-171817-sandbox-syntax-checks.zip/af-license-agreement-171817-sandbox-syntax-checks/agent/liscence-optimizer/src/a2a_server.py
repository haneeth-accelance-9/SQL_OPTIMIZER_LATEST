"""
License Optimizer — A2A Server Entrypoint (SDK 1.2.0+).

Aligned with the agentic-AI platform standard (see af-uc005 / af-uc003 reference MVPs):

  1. Load .env before any SDK imports.
  2. _setup_observability() — LangchainInstrumentor only (SDK reads observability: block in
     config.yaml and calls openlit.init() automatically; double-init would duplicate spans).
  3. _load_agent_card() — loads agent_card.json for A2A protocol discovery.
  4. _add_middlewares() — SecurityHeadersMiddleware + CORSMiddleware wired into FastAPI.
  5. A2AFactory().create_server() — SDK-managed phased-orchestration executor (reads config.yaml).
  6. _register_deterministic_routes() — /health liveness probe + /generate-report
     (LLM-first with deterministic fallback, callable by Django without A2A orchestration).
  7. _call_azure_openai_chat() — APIM header (Ocp-Apim-Subscription-Key) + request_id metadata.

Environment variables (see .env.example for full list):
  AZURE_OPENAI_ENDPOINT          — Azure OpenAI or APIM base URL
  AZURE_OPENAI_API_KEY           — API key (also used as Ocp-Apim-Subscription-Key)
  AZURE_OPENAI_DEPLOYMENT_NAME   — Model deployment name (default: gpt-4o)
  AZURE_OPENAI_API_VERSION       — API version (default: 2024-12-01-preview)
  COSMOSDB_ENDPOINT / COSMOSDB_KEY
  RUNTIME_OTLP_ENDPOINT          — Grafana Cloud OTLP endpoint
  OTEL_EXPORTER_OTLP_HEADERS     — Grafana auth headers
  PORT / HOST                    — Server binding (default: 8001 / 0.0.0.0)
  DEBUGPY_ENABLE / DEBUGPY_WAIT / DEBUGPY_PORT
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

# Load .env BEFORE any SDK or os.environ.get() calls so config substitution works
try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

# Semver: patch = wording only; minor = section added/removed; major = full rewrite
# Increment every time the system/user prompt in _llm_write_report() changes.
PROMPT_VERSION = "1.0.0"

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Observability
# ---------------------------------------------------------------------------

def _setup_observability() -> None:
    """
    Wire LangchainInstrumentor for LangGraph trace grouping.

    The Grafana OTLP exporter is intentionally NOT set up here.
    SDK 1.2.0+ reads the observability: block in config.yaml and calls openlit.init()
    automatically inside A2AFactory().create_server(). Calling GrafanaObservabilityProvider
    here as well would register a second OTLP provider and produce duplicate spans/metrics
    in Grafana. Let the SDK config drive OTLP; this function only adds LangchainInstrumentor
    which the SDK does not configure automatically.
    """
    try:
        from opentelemetry.instrumentation.langchain import LangchainInstrumentor
        LangchainInstrumentor().instrument()
        logger.info("LangchainInstrumentor ready")
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("LangchainInstrumentor failed (%s) — continuing", exc)


# ---------------------------------------------------------------------------
# Agent card  (A2A protocol discovery)
# ---------------------------------------------------------------------------

def _load_agent_card() -> Any:
    """
    Load agent_card.json from the agent root for A2A protocol discovery.

    The card is served at /.well-known/agent-card.json by the SDK so that
    the agent-ui and other A2A callers can discover capabilities without
    hitting a live endpoint (matches af-uc005 pattern).
    """
    try:
        from a2a.types import AgentCard
    except ImportError:
        logger.warning("a2a package not installed — agent card discovery unavailable")
        return None

    card_path = Path(__file__).resolve().parent.parent / "agent_card.json"
    if not card_path.exists():
        logger.warning(
            "agent_card.json not found at %s — A2A discovery falls back to config.yaml", card_path
        )
        return None

    data = json.loads(card_path.read_text(encoding="utf-8"))

    # Inject live URL from environment so the card is always accurate
    port = int(os.environ.get("PORT", "8001"))
    scheme = os.environ.get("AGENT_PUBLIC_SCHEME", "http").lower()
    host = os.environ.get("HOST", "0.0.0.0")
    display_host = "localhost" if host == "0.0.0.0" else host
    data["url"] = f"{scheme}://{display_host}:{port}"

    try:
        card = AgentCard.model_validate(data)
        logger.info("AgentCard loaded: %s  v%s", card.name, card.version)
        return card
    except Exception as exc:
        logger.warning("AgentCard validation failed (%s) — discovery unavailable", exc)
        return None


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

def _add_middlewares(fastapi_app: Any) -> None:
    """
    Wire SecurityHeadersMiddleware and CORSMiddleware into the FastAPI app.

    SecurityHeadersMiddleware sets X-Frame-Options, X-Content-Type-Options,
    Content-Security-Policy and other hardening headers on every response.
    CORSMiddleware is always added; SecurityHeadersMiddleware is best-effort
    (skipped gracefully if the SDK auth extra is not installed).
    """
    try:
        from fastapi.middleware.cors import CORSMiddleware
        cors_origins = [
            o.strip() for o in os.environ.get("CORS_ORIGINS", "*").split(",") if o.strip()
        ]
        fastapi_app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    except Exception as exc:
        logger.warning("CORSMiddleware not added: %s", exc)

    try:
        from agenticai.auth import SecurityHeadersMiddleware
        fastapi_app.add_middleware(
            SecurityHeadersMiddleware,
            csp_policy=(
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' https://alcdn.msauth.net; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self'; "
                "connect-src 'self' https://login.microsoftonline.com https://graph.microsoft.com; "
                "frame-ancestors 'none'"
            ),
        )
        logger.info("SecurityHeadersMiddleware added")
    except ImportError:
        logger.warning("agenticai.auth not available — SecurityHeadersMiddleware skipped")
    except Exception as exc:
        logger.warning("SecurityHeadersMiddleware not added: %s", exc)


# ---------------------------------------------------------------------------
# Guardrails
# ---------------------------------------------------------------------------

try:
    from .guardrails import (
        assess_data_quality,
        filter_llm_output,
        sanitize_prompt_input,
        validate_and_sanitize_records,
    )
except ImportError:
    from guardrails import (  # type: ignore
        assess_data_quality,
        filter_llm_output,
        sanitize_prompt_input,
        validate_and_sanitize_records,
    )


# ---------------------------------------------------------------------------
# SDK + tools
# ---------------------------------------------------------------------------

from agenticai.a2a import A2AFactory

try:
    from . import tools  # noqa: F401
except ImportError:
    import tools  # noqa: F401


# ---------------------------------------------------------------------------
# Deterministic routes  (/health + /generate-report)
# ---------------------------------------------------------------------------

def _register_deterministic_routes(fastapi_app: Any) -> None:
    """
    Register /health and /generate-report on the agent's FastAPI app.

    Why these exist outside the phased-orchestration executor:
    - /health     : liveness probe for Azure Container Apps (no LLM dependency).
    - /generate-report : the Django app calls this directly for a guaranteed report
      even when the LLM orchestrator hits 429 throttling — it runs evaluate_optimization_rules
      + report_generator deterministically, then optionally improves the markdown via LLM.
    """
    try:
        from fastapi import APIRouter
        from pydantic import BaseModel, Field
    except Exception:
        return

    import time

    router = APIRouter()

    # ── /health ──────────────────────────────────────────────────────────────

    @router.get("/health", include_in_schema=False)
    def health() -> dict[str, str]:
        """Liveness probe for Azure Container Apps."""
        return {"status": "healthy"}

    # ── /generate-report helpers ──────────────────────────────────────────────

    try:
        from .tools.evaluate_optimization_rules import evaluate_optimization_rules
        from .tools.report_generator import report_generator
    except Exception:
        from tools.evaluate_optimization_rules import (
            evaluate_optimization_rules,
        )  # type: ignore
        from tools.report_generator import report_generator  # type: ignore

    class GenerateReportRequest(BaseModel):
        usecase_id: str = Field(
            ..., description="Use case identifier for the report title"
        )
        records: list[dict[str, Any]] = Field(
            ..., description="Normalized records (snake_case keys)"
        )
        strategy_results: dict[str, Any] = Field(
            default_factory=dict, description="Upstream strategy outputs (JSON object)"
        )
        notes: Optional[str] = Field(default=None, description="Optional context notes")
        llm_first: bool = Field(
            default=True,
            description="Attempt LLM-written report first; fall back to deterministic on failure.",
        )
        llm_max_retries: int = Field(default=2, description="Max retries on 429/5xx before fallback.")
        llm_timeout_seconds: int = Field(default=60, description="Timeout for the LLM request.")

    def _load_rules_yaml_text() -> str:
        try:
            rules_path = (
                Path(__file__).resolve().parents[2] / "configs" / "rules.base.yaml"
            )
            return rules_path.read_text(encoding="utf-8")
        except Exception:
            return ""

    def _call_azure_openai_chat(
        *, system: str, user: str, timeout_seconds: int
    ) -> tuple[str, dict[str, Any]]:
        """
        Call Azure OpenAI Chat Completions.

        Sends both api-key and Ocp-Apim-Subscription-Key so the same code works
        with a direct Azure OpenAI endpoint and an Azure APIM gateway in front of it.
        The request_id is extracted from the response headers for trace correlation.
        """
        from openai import AzureOpenAI

        endpoint = (os.environ.get("AZURE_OPENAI_ENDPOINT") or "").rstrip("/")
        deployment = (
            os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME")
            or os.environ.get("AZURE_OPENAI_DEPLOYMENT")
            or ""
        )
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION") or "2024-12-01-preview"
        key = os.environ.get("AZURE_OPENAI_API_KEY") or ""

        if not endpoint or not deployment or not key:
            raise RuntimeError(
                "Missing Azure OpenAI env vars (endpoint/deployment/api_key)."
            )

        client = AzureOpenAI(
            api_key=key,
            api_version=api_version,
            azure_endpoint=endpoint,
            timeout=float(timeout_seconds),
            # Ocp-Apim-Subscription-Key is the standard header for Azure APIM gateway auth.
            # Sending it on every request means the same binary works behind both direct
            # Azure OpenAI and the enterprise APIM gateway without any env-var change.
            default_headers={"Ocp-Apim-Subscription-Key": key},
        )

        started = time.time()
        logger.info(
            "Calling Azure OpenAI (deployment=%s api_version=%s)",
            deployment, api_version,
        )

        response = client.chat.completions.create(
            model=deployment,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.2,
            max_tokens=2500,
        )

        elapsed_ms = int((time.time() - started) * 1000)
        content = response.choices[0].message.content
        if not isinstance(content, str) or not content.strip():
            raise RuntimeError("LLM returned empty content.")

        # Pull request-id from underlying HTTP response headers for Grafana trace correlation
        request_id: Optional[str] = None
        try:
            raw_headers = response._response.headers  # type: ignore[attr-defined]
            request_id = (
                raw_headers.get("x-request-id")
                or raw_headers.get("x-ms-request-id")
                or raw_headers.get("apim-request-id")
            )
        except Exception:
            pass

        usage = response.usage
        meta: dict[str, Any] = {
            "elapsed_ms": elapsed_ms,
            "model": deployment,
            "request_id": request_id,
            "prompt_tokens": usage.prompt_tokens if usage else None,
            "completion_tokens": usage.completion_tokens if usage else None,
            "total_tokens": usage.total_tokens if usage else None,
        }
        logger.info(
            "Azure OpenAI succeeded (elapsed_ms=%s request_id=%s prompt_tokens=%s completion_tokens=%s)",
            elapsed_ms, request_id, meta["prompt_tokens"], meta["completion_tokens"],
        )
        return content.strip() + "\n", meta

    def _llm_write_report(
        *,
        usecase_id: str,
        rules_yaml: str,
        rules_evaluation: dict[str, Any],
        strategy_results: dict[str, Any],
        deterministic_markdown: str,
        timeout_seconds: int,
    ) -> tuple[str, dict[str, Any]]:
        system = (
            "You are an IT optimization reporting assistant. "
            "Write a professional, executive-facing Markdown report. "
            "Do not include raw JSON. Do not mention tools, phases, or internal process."
        )
        user = (
            f"Use case id: {usecase_id}\n\n"
            "## Use cases (rules.base.yaml)\n"
            f"{rules_yaml}\n\n"
            "## Rule evaluation results (JSON)\n"
            f"{json.dumps(rules_evaluation, ensure_ascii=False, indent=2)}\n\n"
            "## Strategy results (JSON)\n"
            f"{json.dumps(strategy_results, ensure_ascii=False, indent=2)}\n\n"
            "## Deterministic draft (for structure; you may improve wording)\n"
            f"{deterministic_markdown}\n\n"
            "### Output requirements\n"
            "- Output ONLY Markdown.\n"
            "- Include: Executive summary, Key findings table (rule id + matched count), "
            "per-rule sections with purpose + logic + results + evidence hosts, "
            "recommended actions, risks/caveats.\n"
            "- Use numbers from the provided JSON; do not invent counts.\n"
        )
        return _call_azure_openai_chat(
            system=system, user=user, timeout_seconds=timeout_seconds
        )

    @router.post("/generate-report")
    def generate_report(req: GenerateReportRequest) -> dict[str, Any]:
        """
        LLM-first report generator with deterministic fallback:
          1. sanitize inputs via guardrails
          2. evaluate_optimization_rules (deterministic)
          3. report_generator — builds deterministic markdown scaffold
          4. if llm_first=true: LLM improves the markdown; falls back on 429/5xx
          5. always returns report_markdown (unless step 2 itself fails)
        """
        safe_usecase_id = sanitize_prompt_input(req.usecase_id, field_name="usecase_id")
        safe_notes = (
            sanitize_prompt_input(req.notes, field_name="notes") if req.notes else req.notes
        )
        safe_records = validate_and_sanitize_records(req.records)
        quality_report = assess_data_quality(safe_records)

        eval_json_str = evaluate_optimization_rules(records_json=json.dumps(safe_records))
        eval_obj = (
            json.loads(eval_json_str)
            if eval_json_str
            else {"success": False, "error": "Empty evaluation"}
        )

        if not eval_obj or not eval_obj.get("success", False):
            return {
                "success": False,
                "error": eval_obj.get("error") or "Rules evaluation failed",
                "rules_evaluation": eval_obj,
            }

        report_json_str = report_generator(
            usecase_id=safe_usecase_id,
            strategy_results_json=json.dumps(req.strategy_results or {}),
            rules_evaluation_json=json.dumps(eval_obj),
            notes=safe_notes,
            data_quality_json=json.dumps(quality_report.to_dict()),
        )
        report_obj = (
            json.loads(report_json_str)
            if report_json_str
            else {"success": False, "error": "Empty report"}
        )

        if not report_obj.get("success"):
            return {
                "success": False,
                "error": report_obj.get("error") or "Report generation failed",
                "rules_evaluation": eval_obj,
            }

        deterministic_md = report_obj.get("markdown", "") or ""
        final_md = deterministic_md
        llm_used = False
        llm_error: Optional[str] = None
        llm_meta: dict[str, Any] = {}

        if req.llm_first:
            rules_yaml = _load_rules_yaml_text()
            for attempt in range(max(0, int(req.llm_max_retries)) + 1):
                try:
                    raw_md, llm_meta = _llm_write_report(
                        usecase_id=safe_usecase_id,
                        rules_yaml=rules_yaml,
                        rules_evaluation=eval_obj,
                        strategy_results=req.strategy_results or {},
                        deterministic_markdown=deterministic_md,
                        timeout_seconds=int(req.llm_timeout_seconds),
                    )
                    final_md = filter_llm_output(raw_md)
                    llm_used = True
                    llm_error = None
                    break
                except Exception as e:
                    import openai as _openai
                    llm_error = str(e)
                    retryable = isinstance(
                        e,
                        (
                            _openai.RateLimitError,
                            _openai.InternalServerError,
                            _openai.APITimeoutError,
                            _openai.APIConnectionError,
                        ),
                    )
                    if retryable and attempt < int(req.llm_max_retries):
                        time.sleep(2 ** attempt)
                        continue
                    break

        return {
            "success": True,
            "usecase_id": req.usecase_id,
            "rules_evaluation": eval_obj,
            "report_markdown": final_md,
            "llm_used": llm_used,
            "llm_error": llm_error,
            "llm_meta": llm_meta if llm_used else None,
            "deterministic_report_markdown": deterministic_md,
            "data_quality": quality_report.to_dict(),
        }

    fastapi_app.include_router(router)


# ---------------------------------------------------------------------------
# Debugpy helper
# ---------------------------------------------------------------------------

def _enable_debugpy() -> None:
    if os.environ.get("DEBUGPY_ENABLE", "").lower() != "true":
        return
    try:
        import debugpy
        port = int(os.environ.get("DEBUGPY_PORT", "5678"))
        debugpy.listen(("0.0.0.0", port))  # nosec B104 — intentional for VS Code remote debugging
        logger.info("debugpy listening on port %d", port)
        if os.environ.get("DEBUGPY_WAIT", "").lower() == "true":
            logger.info("Waiting for VS Code debugger to attach...")
            debugpy.wait_for_client()
            logger.info("Debugger attached")
    except ImportError:
        logger.warning("debugpy not installed — continuing without debugger")
    except Exception as exc:
        logger.warning("debugpy setup failed: %s", exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Start the License Optimizer A2A server."""
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )

    # 1. Debugger (before anything else so breakpoints work from startup)
    _enable_debugpy()

    # 2. Observability — must be before any span-creating SDK calls
    _setup_observability()

    # 3. Load agent card for A2A protocol discovery
    _load_agent_card()

    # 4. Boot the SDK-managed phased-orchestration server (reads config.yaml)
    factory = A2AFactory()
    server = factory.create_server()

    # 5. Wire security + CORS middleware into the FastAPI app
    _add_middlewares(server.fastapi_app)

    # 6. Register /health (liveness probe) + /generate-report (Django direct-call path)
    _register_deterministic_routes(server.fastapi_app)

    logger.info("License Optimizer agent server ready")
    server.run()


if __name__ == "__main__":
    main()
